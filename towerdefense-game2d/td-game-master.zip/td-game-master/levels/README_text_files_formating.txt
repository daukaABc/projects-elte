----------------------------- Text Files Formating------------------------------------

The files describing the layout of the levels (those in that form : levelX.txt) are formated like the folowing :
- each integer represent a 32x32 tile in the final map.
- the position of each integer is the real position it'll have in the map grid.


Regarding modifications :
- you can modify the existing file as you want (we cannot make sure that it will be playable tho)
- please to write all the integers <10 with two digits (01, 02, etc) so that it is still readable


The files describing the main locations of the enemies path
